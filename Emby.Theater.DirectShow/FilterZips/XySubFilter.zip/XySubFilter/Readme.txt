To Install:
Right-click Install_XySubFilter.bat and select "Run as administrator"

To Uninstall:
Right-click Uninstall_XySubFilter.bat and select "Run as administrator"