madVR - DirectShow video renderer
http://madVR.madshi.net
http://madVR.bugs.madshi.net


======================================================================


INSTALL
----------------------------------------------------------------------
 (1) Unzip "madVR.zip" and copy the folder to a suitable place (e.g.
     Program Files).

 (2) Run "install.bat". (with admin rights!)

 (3) Do not delete the madVR folder after installation.


UNINSTALL
----------------------------------------------------------------------
 Run "uninstall.bat". (with admin rights!)


USAGE
----------------------------------------------------------------------
 Use MPC HC or any other media player which supports madVR. Select
 madVR as the preferred renderer in the media player's settings.


REQUIREMENTS
----------------------------------------------------------------------
 You will need a graphics card with full Direct3D9 hardware support.


CHANGES
----------------------------------------------------------------------
 See "changlog.txt".


BUG TRACKER
----------------------------------------------------------------------
 http://madVR.bugs.madshi.net


LICENSE
----------------------------------------------------------------------
 See "license.txt".


CONTRIBUTIONS & THANKS
----------------------------------------------------------------------
 Thanks a lot to Nicolas Robidoux for his help during madVR scaling
 development, and for introducing the concept of doing linear 1-pass
 2D Jinc resampling.

 Thanks a bunch to SEt for creating a well optimized OpenCL NNEDI3
 kernel, and for making it available under LGPL, so I could use it
 in madVR. Here's SEt's OpenCL NNEDI3 doom9 thread:
 http://forum.doom9.org/showthread.php?t=169766

 Thanks to Shiandow for his dithering ideas (e.g. gamma correction).
